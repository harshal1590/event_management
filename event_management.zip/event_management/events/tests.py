from rest_framework.test import APITestCase
from rest_framework import status
from .models import Event

class EventTestCase(APITestCase):
    def test_create_event(self):
        data = {
            "name": "Tech Conference",
            "description": "Annual tech meetup",
            "start_time": "2024-12-01T10:00:00Z",
            "end_time": "2024-12-01T18:00:00Z",
            "location": "Mumbai",
            "max_attendees": 100
        }
        response = self.client.post('/api/events/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_register_attendee(self):
        event = Event.objects.create(
            name="Tech Conference",
            description="Annual tech meetup",
            start_time="2024-12-01T10:00:00Z",
            end_time="2024-12-01T18:00:00Z",
            location="Mumbai",
            max_attendees=100
        )
        data = {
            "first_name": "John",
            "last_name": "Doe",
            "email": "johndoe@example.com",
            "phone_number": "1234567890",
            "event": event.id
        }
        response = self.client.post('/api/attendees/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
