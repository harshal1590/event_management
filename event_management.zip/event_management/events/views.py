from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone
from .models import Event, Attendee
from .serializers import EventSerializer, AttendeeSerializer

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer

    def perform_update(self, serializer):
        event = self.get_object()
        if event.end_time < timezone.now():
            serializer.save(status='completed')
        else:
            serializer.save()

    @action(detail=False, methods=['get'])
    def filter_events(self, request):
        status = request.query_params.get('status')
        location = request.query_params.get('location')
        events = self.queryset
        if status:
            events = events.filter(status=status)
        if location:
            events = events.filter(location=location)
        serializer = self.get_serializer(events, many=True)
        return Response(serializer.data)

class AttendeeViewSet(viewsets.ModelViewSet):
    queryset = Attendee.objects.all()
    serializer_class = AttendeeSerializer

    @action(detail=False, methods=['post'])
    def bulk_check_in(self, request):
        csv_file = request.FILES.get('file')
        # Implement CSV parsing and bulk check-in logic
        return Response({"message": "Bulk check-in completed."}, status=status.HTTP_200_OK)
